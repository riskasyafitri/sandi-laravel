<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Tamplatecontroller extends Controller
{
    public function index()
    {
        return view('tamplate.base');
    }

}
